

a1 <- read.csv("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/mcmc_summary1.csv")
a1 <- as.matrix(a1)
a1 <- a1[,-1]

a2 <- read.csv("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/mcmc_summary2.csv")
a2 <- as.matrix(a2)
a2 <- a2[,-1]

table <- matrix(NA,17,3)
table[1,2:3] <- c("A(H3N2)","B")
table[2:17,1] <- c("Age"," <6"," 0-17"," >17","Vaccintion"," No"," Yes","Community type"," 1"," 2"," 3"," 4"," 5","Household size"," 2-4"," >4")

table1 <- matrix(NA,17,3)
table1[3:4,] <- exp(a1[7:8,1:3])
table1[8,] <- exp(a1[9,1:3])
table1[c(11:14,17),] <- exp(a1[c(10:13,21),1:3])

table1 <- round(table1,2)
table[,2] <- paste(table1[,1]," (",table1[,2],", ",table1[,3],")",sep="")

################# B
table1 <- matrix(NA,17,3)
table1[3:4,] <- exp(a2[7:8,1:3])
table1[8,] <- exp(a2[9,1:3])
table1[c(11:14,17),] <- exp(a2[c(10:13,21),1:3])

table1 <- round(table1,2)
table[,3] <- paste(table1[,1]," (",table1[,2],", ",table1[,3],")",sep="")

table[1,2:3] <- c("A(H3N2)","B")


table[grepl("NA",table)] <- " "
table[c(5,7,10,16),2:3] <- "Ref"
table <- table[-3,]

write.csv(table,"/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/summary/tableS2.csv")