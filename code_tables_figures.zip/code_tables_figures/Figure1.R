
library(chron)


########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
    y[i,1] <- mean(mcmc[,i])
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

h3 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1/mcmc_result1.csv")
b <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1/mcmc_result2.csv")

h3 <- h3[10000+1:10000*2,-1]
b <- b[10000+1:10000*2,-1]

h3 <- cbind(0,h3[,10:13])
b <- cbind(0,b[,10:13])

a1 <- a2 <- matrix(0,10000,25)

a1[,1:5] <- as.matrix(h3)
a1[,6:10] <- as.matrix(h3)-h3[,2]
a1[,11:15] <- as.matrix(h3)-h3[,3]
a1[,16:20] <- as.matrix(h3)-h3[,4]
a1[,21:25] <- as.matrix(h3)-h3[,5]

a2[,1:5] <- as.matrix(b)
a2[,6:10] <- as.matrix(b)-b[,2]
a2[,11:15] <- as.matrix(b)-b[,3]
a2[,16:20] <- as.matrix(b)-b[,4]
a2[,21:25] <- as.matrix(b)-b[,5]

a11 <- para_summary(a1,4,3,0)
a21 <- para_summary(a2,4,3,0)



a111 <- round(exp(a11),2)
a211 <- round(exp(a21),2)

a1111 <- paste(a111[,1]," (",a111[,2],", ",a111[,3],")",sep="")
a2111 <- paste(a211[,1]," (",a211[,2],", ",a211[,3],")",sep="")

out <- matrix(NA,11,5)
out[1:5,1:5] <- matrix(a1111,nrow=5)
out[1:5+6,1:5] <- matrix(a2111,nrow=5)

diag(out[1:5,]) <- 1 
diag(out[7:11,]) <- 1 

write.csv(out,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/summary/tableS2.csv")


table1 <- log2(exp(a11))
table2 <- log2(exp(a21))





pdf("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/summary/figure1.pdf",width=8, height=6)

layout(matrix( 1:2, nrow=2,byrow=T))


par(mar=c(5,6,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,5.5), ylim=c(-5,5),type="n")

cc <- c(0.5,1.5,2.5,3.5,4.5) 

axis(1,at=c(-0.5,cc,6.5),labels=c(NA,"Ref: Type 1","Ref: Type 2","Ref: Type 3","Ref: Type 4","Ref: Type 5",NA),cex.axis=1)
axis(2,at=-5:5,labels=2^(-5:5),las=1, pos=-0.2)

points(cc-0.2,table1[0:4*5+1,1],pch=15,col="black",cex=0.8)
points(cc-0.1,table1[0:4*5+2,1],pch=16,col="purple",cex=0.8)
points(cc-0,table1[0:4*5+3,1],pch=17,col="blue",cex=0.8)
points(cc+0.1,table1[0:4*5+4,1],pch=18,col="red",cex=0.8)
points(cc+0.2,table1[0:4*5+5,1],pch=20,col="orange",cex=0.8)

for (i in 1:5){
  lines(rep(cc[i]-0.2,2),pmin(5,pmax(table1[(i-1)*5+1,2:3],-5.4),5.4),col="black")  
  lines(rep(cc[i]-0.1,2),pmin(5,pmax(table1[(i-1)*5+2,2:3],-5.4),5.4),col="purple")  
  lines(rep(cc[i],2),pmin(5,pmax(table1[(i-1)*5+3,2:3],-5),5.4),col="blue")  
  lines(rep(cc[i]+0.1,2),pmin(5,pmax(table1[(i-1)*5+4,2:3],-5.4),5.4),col="red")  
  lines(rep(cc[i]+0.2,2),pmin(5,pmax(table1[(i-1)*5+5,2:3],-5.4),5.4),col="orange")  
}

arrows(0.6,-4,0.6,-5.4,col="red",length=0.05)
arrows(1.6,-4,1.6,-5.4,col="red",length=0.05)
arrows(2.6,-4,2.6,-5.4,col="red",length=0.05)
arrows(4.6,-4,4.6,-5.4,col="red",length=0.05)

arrows(3.3,4,3.3,5.4,col="black",length=0.05)
arrows(3.4,4,3.4,5.4,col="purple",length=0.05)
arrows(3.5,4,3.5,5.4,col="blue",length=0.05)
arrows(3.7,4,3.7,5.4,col="orange",length=0.05)

abline(h=0,lty=2)

mtext("Relative susceptibility",side=2,line=4.5)


mtext("Community type",side=1,cex=1,line=2.5)


legend(5,5.5, cex=0.7, legend=c(paste("Type",1:5)),lty=1,pch=c(15,16,17,18,20),col=c("black","purple","blue","red","orange"),bty="n")

title(main="A", adj=0)
mtext("Influenza A(H3N2)",side=3,cex=1,line=0.5)


#######
## B


par(mar=c(5,6,1,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,5.5), ylim=c(-5,5),type="n")

cc <- c(0.5,1.5,2.5,3.5,4.5) 

axis(1,at=c(-0.5,cc,6.5),labels=c(NA,"Ref: Type 1","Ref: Type 2","Ref: Type 3","Ref: Type 4","Ref: Type 5",NA),cex.axis=1)
axis(2,at=-5:5,labels=2^(-5:5),las=1, pos=-0.2)

points(cc-0.2,table2[0:4*5+1,1],pch=15,col="black",cex=0.8)
points(cc-0.1,table2[0:4*5+2,1],pch=16,col="purple",cex=0.8)
points(cc-0,table2[0:4*5+3,1],pch=17,col="blue",cex=0.8)
points(cc+0.1,table2[0:4*5+4,1],pch=18,col="red",cex=0.8)
points(cc+0.2,table2[0:4*5+5,1],pch=20,col="orange",cex=0.8)

for (i in 1:5){
  lines(rep(cc[i]-0.2,2),pmin(5,pmax(table2[(i-1)*5+1,2:3],-5.4),5.4),col="black")  
  lines(rep(cc[i]-0.1,2),pmin(5,pmax(table2[(i-1)*5+2,2:3],-5.4),5.4),col="purple")  
  lines(rep(cc[i],2),pmin(5,pmax(table2[(i-1)*5+3,2:3],-5.4),5.4),col="blue")  
  lines(rep(cc[i]+0.1,2),pmin(5,pmax(table2[(i-1)*5+4,2:3],-5.4),5.4),col="red")  
  lines(rep(cc[i]+0.2,2),pmin(5,pmax(table2[(i-1)*5+5,2:3],-5.4),5.4),col="orange")  
}

arrows(4.3,4,4.3,5.4,col="black",length=0.05)
arrows(4.4,4,4.4,5.4,col="purple",length=0.05)
arrows(4.5,4,4.5,5.4,col="blue",length=0.05)
arrows(4.6,4,4.6,5.4,col="red",length=0.05)

arrows(0.7,-4,0.7,-5.4,col="orange",length=0.05)
arrows(1.7,-4,1.7,-5.4,col="orange",length=0.05)
arrows(2.7,-4,2.7,-5.4,col="orange",length=0.05)
arrows(3.7,-4,3.7,-5.4,col="orange",length=0.05)

abline(h=0,lty=2)


legend(5,5.5, cex=0.7, legend=c(paste("Type",1:5)),lty=1,pch=c(15,16,17,18,20),col=c("black","purple","blue","red","orange"),bty="n")


mtext("Relative susceptibility",side=2,line=4.5)



mtext("Community type",side=1,cex=1,line=2.5)

title(main="B", adj=0)
mtext("Influenza B",side=3,cex=1,line=0.5)



dev.off()







