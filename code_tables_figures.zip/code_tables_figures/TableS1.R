
########

setwd("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/data")

data1 <- as.matrix(read.csv("2018_06_09_data.csv"))
data1[data1[,1]==135,4] <- 817
data1[data1[,1]==127,4] <- 810

data2 <- as.matrix(read.csv("2018_06_09_prob.csv"))
data3 <- as.matrix(read.csv("2018_06_09_oligotype.csv"))

data4 <- matrix(NA,647,18)
index <- 1

for (i in 1:nrow(data1)){
  for (j in 1:data1[i,2]){
    if (data1[i,5+10*(j-1)+5]>0){
     
      data4[index,1:15] <- 10^(data3[i,15*(j-1)+1:15])
      data4[index,16] <- data1[i,5+10*(j-1)+10]
      data4[index,17] <- data1[i,3]
      data4[index,18] <- j-1
      index <- index + 1
    }
  }
}

out <- matrix(NA,15,10)

data4 <- data4[data4[,16]!=-1,]
data41 <- data4[data4[,17]==2&data4[,18]!=0,]
data42 <- data4[data4[,17]==3&data4[,18]!=0,]

for (i in 1:5){
data411 <- data41[data41[,16]==i,]
out[,i] <- colSums(data411[,1:15])/sum(colSums(data411[,1:15]))
data411 <- data42[data42[,16]==i,]
out[,i+5] <- colSums(data411[,1:15])/sum(colSums(data411[,1:15]))
}

write.csv(round(out,3),"/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/summary/tableS1.csv")

