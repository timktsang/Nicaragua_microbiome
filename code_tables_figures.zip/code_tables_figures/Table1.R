### create dataset that excude all nips household


rm(list = ls())

library(chron)

load("/Users/timtsang/Dropbox/Nicaragua_flu/community_type/rawdata/NHTS_1.rda")

load("/Users/timtsang/Dropbox/Nicaragua_flu/community_type/rawdata/NHTS_2.rda")

load("/Users/timtsang/Dropbox/Nicaragua_flu/community_type/rawdata/NHTS_3.rda")

data1 <- NHTS_1
data2 <- NHTS_2 
data3 <- NHTS_3

data1 <- merge(data1,data3,by="codigoeventoTR",all.x=T)

data1 <- data1[order(data1$Codigo_Casa),]

#dcabeza	Headache
#dgarganta	Sore throat
#diarrea	Diarrhea
#dmuscular	Myalgia
#f_sint	Symptom date
#fiebre	Fever
#papetito	Poor appetite
#rruidosa	Respiratory distress / wheezing
#snasal	Rhinorrhea
#tos	Cough
#toselta	Oseltamivir

data2$ILI <- (data2$fiebre==1)*(data2$tos==1||data2$dgarganta==1)
data2$ARI <- 1*(rowSums(data2[,c("fiebre","dgarganta","dmuscular","tos","dcabeza","rruidosa","snasal")],na.rm=T)>=2)
data2$ARI2 <- 1*(rowSums(data2[,c("fiebre","dgarganta","dmuscular","tos","dcabeza","rruidosa","snasal")],na.rm=T)>=1)
data2$fiebre[is.na(data2$fiebre)] <- 0


head(data1[data1$type=="index",])

## set 2012/07/01 as day1
data1$EnrollmentDate <- dates(as.character(data1$EnrollmentDate),format="y-m-d")-dates("06/30/2012")
data1$TR1Fecha <- dates(as.character(data1$TR1Fecha),format="y-m-d")-dates("06/30/2012")
data1$TR2Fecha <- dates(as.character(data1$TR2Fecha),format="y-m-d")-dates("06/30/2012")
data1$TR3Fecha <- dates(as.character(data1$TR3Fecha),format="y-m-d")-dates("06/30/2012")
data1$TR4Fecha <- dates(as.character(data1$TR4Fecha),format="y-m-d")-dates("06/30/2012")
data1$TR5Fecha <- dates(as.character(data1$TR5Fecha),format="y-m-d")-dates("06/30/2012")
data1$FIFiebre <- dates(as.character(data1$FIFiebre),format="y-m-d")-dates("06/30/2012")
data2$f_sint <- dates(as.character(data2$f_sint),format="y-m-d")-dates("06/30/2012")


# household id with mixed subtype
# 15  16  18  25  28  29  37  49  58  63 124 125 130 163
data1[data1[,1]%in%c("30112.01","30234.01","30506.02"),]$ResFin <- 1

data1[data1[,1]%in%c("30119.01","7010.01"),]$ResFin <- 1
data1[data1[,1]%in%c("2704.01","30071.01","30071.02"),]$ResFin <- 2
data1[data1[,1]%in%c("6822.01"),]$ResFin <- 3

# more than 1
# 15,18,28,37,49,58,63,125,130,163
# exclude the infection that don't match the type
exclude1 <- c("30063.01","30064.01","30071.01","30072.01","5139.01","30112.01","30135.01","442.01","30169.01","30165.01","6195.01","30234.01","30400.01","30422.01","30506.02")
exclude1 <- data1[data1[,1]%in%exclude1,2]
data1 <- data1[!(data1[,2]%in%exclude1),]

# followmax
data1$followmin <- pmin(data1$TR1Fecha,data1$TR2Fecha,data1$TR3Fecha,data1$TR4Fecha,data1$TR5Fecha,na.rm=T)
data1$followmax <- pmax(data1$TR1Fecha,data1$TR2Fecha,data1$TR3Fecha,data1$TR4Fecha,data1$TR5Fecha,na.rm=T)

data1[,1] <- as.numeric(data1[,1])

## get the earliest PCR postive visit
data1$earliestPCR <- 0
for (i in 5:1){
  data1[data1[,paste("tr",i,"res",sep="")]>0&!is.na(data1[,paste("tr",i,"res",sep="")]),]$earliestPCR <- i
}

# here to create the earliset symptom onset date first ## ignore real symtpom data
# assume incubation is 1 day, so eg if -ve for visit1 and +ve for visit2, then the earlist one should be visit 1 's date + 2
data1$earliestsymptom <- NA
data1$earliestsymptom[data1$earliestPCR==1] <- 1#data1$TR1Fecha[data1$earliestPCR==1]
#data1$earliestsymptom[data1$earliestPCR==1&data1$type!="index"] <- data1$EnrollmentDate[data1$earliestPCR==1&data1$type!="index"]
for (i in 2:5){
  data1$earliestsymptom[data1$earliestPCR==i] <- data1[data1$earliestPCR==i,11+i]+2  #data1[data1$earliestPCR==i,12+i]-1 
}

## create col about the index community type
data1$indexcomp <- NA
data1$nipshousehold <- NA
data1$antiviral <- NA
data1$nsecondary <- NA
data1$nsize <- NA
#data1[is.na(data1$comp),]$comp <- 6
data1[is.na(data1$vacsameyear),]$vacsameyear <- 0
data1$householdsubtype <- NA
data1$ILIdate <- NA
data1$ARIdate <- NA
data1$ARI2date <- NA


for (i in 1:max(data1$Codigo_Casa)){
  temp <- data1[data1$Codigo_Casa == i,]
  if (nrow(temp)>0){
    data1[data1$Codigo_Casa == i,]$indexcomp <- data1[data1$Codigo_Casa == i&data1$type=="index",]$comp
    data1[data1$Codigo_Casa == i,]$nipshousehold <- 1*(sum(data1[data1$Codigo_Casa == i,]$type=="nips")>0)
    temp2 <- data2[data2[,1]==temp[temp$type=="index",]$codigoeventoTR,]
    data1[data1$Codigo_Casa == i,]$antiviral <- 1*(sum(temp2$toselta)>0)
    data1[data1$Codigo_Casa == i,]$nsecondary <- sum(temp$ResFin>0)-1
    data1[data1$Codigo_Casa == i,]$nsize <- nrow(temp)
    
    type <- unique(temp$ResFin)
    type <- type[type!=0]
    if (length(type)==1){
      data1[data1$Codigo_Casa == i,]$householdsubtype <- type
    }
    else{
      data1[data1$Codigo_Casa == i,]$householdsubtype <- 4      
    }
  }
}


## craete data set as follow:
## 1. hhID, 2.size, 3 influenza type ,4-5: follow start and end date 
## 5 + 1. infectious status, 2. infection time, 3,4.start and end of follow-up 5.id 
## 6.age, 7.sex, 8.vaccination, 9.oseltamivir treatment, 10.community type

data <- read.csv("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/data/2018_04_18_data.csv")

## create col about the index community type
data1$indexcomp <- NA
data1$nipshousehold <- NA
data1$antiviral <- NA
data1$nsecondary <- NA
data1$nsize <- NA
data1[is.na(data1$comp),]$comp <- 6
data1[is.na(data1$vacsameyear),]$vacsameyear <- 0

for (i in 1:max(data1$Codigo_Casa)){
temp <- data1[data1$Codigo_Casa == i,]
if (nrow(temp)>0){
data1[data1$Codigo_Casa == i,]$indexcomp <- data1[data1$Codigo_Casa == i&data1$type=="index",]$comp
data1[data1$Codigo_Casa == i,]$nipshousehold <- 1*(sum(data1[data1$Codigo_Casa == i,]$type=="nips")>0)
temp2 <- data2[data2[,1]==temp[temp$type=="index",]$codigoeventoTR,]
oseresult <- 0
if (sum(temp2$toselta==1,na.rm=T)>0){
oseresult <- 1*(min(temp2[temp2$toselta==1,]$f_sint) - temp[temp$type=="index",]$FIFiebre <= 2)
}
data1[data1$Codigo_Casa == i,]$antiviral <- oseresult
data1[data1$Codigo_Casa == i,]$nsecondary <- sum(temp$ResFin>0)-1
data1[data1$Codigo_Casa == i,]$nsize <- nrow(temp)
}
}

#use 6 to denote NA for comp type

## adding ths symptom here
data1$sorethroat <- 0
data1$cough <- 0
data1$fever <- 0
data1$rhinorrhea <- 0
for (i in 1:nrow(data1)){
temp <- data2[data2$codigoeventoTR==data1$codigoeventoTR[i],]
data1$sorethroat[i] <- 1*(sum(temp$dgarganta,na.rm = T)>0) 
data1$cough[i] <- 1*(sum(temp$tos,na.rm = T)>0) 
data1$fever[i] <- 1*(sum(temp$fiebre,na.rm = T)>0) 
data1$rhinorrhea[i] <- 1*(sum(temp$snasal,na.rm = T)>0) 
}
data1$ILI <- 1*(data1$fever==1)*(data1$cough+data1$sorethroat>=1)

table1 <- data.frame(matrix(NA,69,3))
#table1[1,2:3] <- c("A(H3N2)","B")
table1[2:69,1] <- c("Index cases","No. of index cases","Age"," 0-5"," 6-17"," >17","Sex"," Female"," Male","Prior vaccination"," Yes"," No","Oseltamivir treatment"," Yes"," No","Community type"," 1"," 2"," 3"," 4"," 5","missing"
                    ,"Number of household contacts"," 1-3"," 4-5"," >5","Number of secondary cases in household"," 0"," 1"," 2"," >2"," ","Household contacts","No. of contacts","Age"," 0-5"," 6-17"," >17","Sex"," Female",
                    " Male","Prior vaccination"," Yes"," No","Community type"," 1"," 2"," 3"," 4"," 5"," missing","With confirmed infection"," Overall"," 0-5"," 6-17"," >17"," ","Fever","Rhinorrhea","Sore throat","Cough","ILI"," ","Fever","Rhinorrhea","Sore throat","Cough","ILI")

#data1 <- data1[data1$Codigo_Casa%in%data[,1],]
#data1 <- data1[data1$nipshousehold==0,]


for (i in 1:2){

temp11 <- data1[data1$householdsubtype==i+1&data1$type=="index",]
temp12 <- data1[data1$householdsubtype==i+1&data1$type!="index",]

table1[3,i+1] <- nrow(temp11)
table1[5,i+1] <- sum(temp11$Age<6)
table1[6,i+1] <- sum(temp11$Age>=6&temp11$Age<18)
table1[7,i+1] <- sum(temp11$Age>=18)
table1[9,i+1] <- sum(temp11$Sex=="F")
table1[10,i+1] <- sum(temp11$Sex=="M")
table1[12,i+1] <- sum(temp11$vacsameyear==1)
table1[13,i+1] <- sum(temp11$vacsameyear==0)
table1[15,i+1] <- sum(temp11$antiviral==1)
table1[16,i+1] <- sum(temp11$antiviral==0)
table1[18,i+1] <- sum(temp11$comp==1)
table1[19,i+1] <- sum(temp11$comp==2)
table1[20,i+1] <- sum(temp11$comp==3)
table1[21,i+1] <- sum(temp11$comp==4)
table1[22,i+1] <- sum(temp11$comp==5)
table1[23,i+1] <- sum(temp11$comp==6)
table1[25,i+1] <- sum(temp11$nsize<5)
table1[26,i+1] <- sum(temp11$nsize>=5&temp11$nsize<=6)
table1[27,i+1] <- sum(temp11$nsize>6)
table1[29,i+1] <- sum(temp11$nsecondary==0)
table1[30,i+1] <- sum(temp11$nsecondary==1)
table1[31,i+1] <- sum(temp11$nsecondary==2)
table1[32,i+1] <- sum(temp11$nsecondary>2)

table1[59,i+1] <- sum(temp11$fever==1)
table1[60,i+1] <- sum(temp11$rhinorrhea==1)
table1[61,i+1] <- sum(temp11$sorethroat==1)
table1[62,i+1] <- sum(temp11$cough==1)
table1[63,i+1] <- sum(temp11$ILI==1)
                      

table1[35,i+1] <- nrow(temp12)
table1[37,i+1] <- sum(temp12$Age<=5)
table1[38,i+1] <- sum(temp12$Age>=6& temp12$Age<=17)
table1[39,i+1] <- sum(temp12$Age>17)
table1[41,i+1] <- sum(temp12$Sex=="F")
table1[42,i+1] <- sum(temp12$Sex=="M")
table1[44,i+1] <- sum(temp12$vacsameyear==1)
table1[45,i+1] <- sum(temp12$vacsameyear==0)
table1[47,i+1] <- sum(temp12$comp==1)
table1[48,i+1] <- sum(temp12$comp==2)
table1[49,i+1] <- sum(temp12$comp==3)
table1[50,i+1] <- sum(temp12$comp==4)
table1[51,i+1] <- sum(temp12$comp==5)
table1[52,i+1] <- sum(temp12$comp==6)
table1[54,i+1] <- sum(temp12$ResFin>0)
table1[55,i+1] <- sum(temp12$ResFin>0&temp12$Age<=5)
table1[56,i+1] <- sum(temp12$ResFin>0&temp12$Age>=6&temp12$Age<18)
table1[57,i+1] <- sum(temp12$ResFin>0&temp12$Age>=18)

table1[65,i+1] <- sum(temp12$fever==1&temp12$ResFin>0)
table1[66,i+1] <- sum(temp12$rhinorrhea==1&temp12$ResFin>0)
table1[67,i+1] <- sum(temp12$sorethroat==1&temp12$ResFin>0)
table1[68,i+1] <- sum(temp12$cough==1&temp12$ResFin>0)
table1[69,i+1] <- sum(temp12$ILI==1&temp12$ResFin>0)

}



table2 <- table1
table2[c(5:7,9:10,12:13,15:16,18:23,25:27,29:32,59:63),2:3] <- table1[c(5:7,9:10,12:13,15:16,18:23,25:27,29:32,59:63),2:3]/table1[rep(3,27),2:3]*100

table2[c(37:39,41:42,44:45,47:52,54),2:3] <- table1[c(37:39,41:42,44:45,47:52,54),2:3]/table1[rep(35,14),2:3]*100

table2[c(55:57),2:3] <- table1[c(55:57),2:3]/table1[c(37:39),2:3]*100

table2[c(65:69),2:3] <- table1[c(65:69),2:3]/table1[rep(54,5),2:3]*100



table2[,2:3] <- round(table2[,2:3])

table3 <- table1

for (i in 2:3){
table3[,i] <- paste(table1[,i]," (",table2[,i],"%)",sep="")
table3[grepl("NA",table3[,i]),i] <- " "
}

table3[c(3,35),2:3] <- table1[c(3,35),2:3]



write.csv(table3,"/Users/timtsang/Dropbox/Nicaragua_flu/community_type/summary/2019_08_13_table1.csv")



