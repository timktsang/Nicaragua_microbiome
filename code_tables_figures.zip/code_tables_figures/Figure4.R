# SI
library(Rcpp)
library(RcppParallel)
library(chron)

h3 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1/mcmc_result1.csv")
b <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1/mcmc_result2.csv")

h3 <- h3[10000+1:10000*2,]
b <- b[10000+1:10000*2,]


########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

sourceCpp("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1/community_type.cpp")

t1 <- t2 <- matrix(NA,10000,14)

for (i in 1:10000){
t1[i,1:14] <- serial_density(h3[i,2],h3[i,3])/sum(serial_density(h3[i,2],h3[i,3]))
t2[i,1:14] <- serial_density(b[i,2],b[i,3])/sum(serial_density(b[i,2],b[i,3]))
}

prob_matrix2 <- matrix(NA,4,14)
for (i in 1:14){
a1 <- quantile(t1[,i],c(0.5,0.025,0.975)) 

prob_matrix2[1,i] <- sd(t1[,i])
a1 <- quantile(t2[,i],c(0.5,0.025,0.975))
prob_matrix2[3,i] <- sd(t2[,i])
}

prob_matrix <- matrix(NA,4,14)
prob_matrix[2,] <- serial_density(median(h3[,2]),median(h3[,3]))
prob_matrix[4,] <- serial_density(median(b[,2]),median(b[,3]))


data1 <- as.matrix(read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1/2018_04_18_data.csv"))
data1[data1[,1]==135,4] <- 817
data1[data1[,1]==127,4] <- 810

data11 <- data1[data1[,3]==2,]
data12 <- data1[data1[,3]==3,]

a1 <- as.vector(data11[,1:16*10+7]-data11[,7])
a1 <- a1[a1>0]
a2 <- as.vector(data12[,1:16*10+7]-data12[,7])
a2 <- a2[a2>0]

for (i in 1:14){
prob_matrix[1,i] <- mean(a1==i)
prob_matrix[3,i] <- mean(a2==i)
}


pdf("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/summary/figure4_v2.pdf",width=4, height=3.8)



par(mar=c(4,4,1,1))

barplot(prob_matrix[c(2,4),1:8],beside=TRUE,col=c("red","blue"),axes=FALSE,ylim=c(0,0.7))
axis(1, at=c(-1,3*0:8+2,25),labels=c(NA,1:9,NA),cex=0.9, pos=0)
axis(2, at=0:8*0.1, las=1, cex=0.8, pos=0)

points(2+0:7*3-0.5,prob_matrix[2,1:8],cex=0.5,pch=16)
points(2+0:7*3+0.5,prob_matrix[4,1:8],cex=0.5,pch=16)

for ( i in 0:7){
  lines(rep(2+i*3-0.5,2),prob_matrix[2,i+1]+ c(-1.96,1.96)*prob_matrix2[1,i+1])
  lines(rep(2+i*3+0.5,2),prob_matrix[4,i+1]+ c(-1.96,1.96)*prob_matrix2[3,i+1])
}



mtext("Probability",side = 2, line = 2.9,cex = 1)
mtext("Days since illness onset in the index case",side = 1, line = 2.5,cex = 1)

legend(15,0.7, legend=c("A(H3N2)","B"),cex=0.8, fill=c("red","blue"),bty="n")


dev.off()



