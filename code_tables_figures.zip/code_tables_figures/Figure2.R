
library(chron)


########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.05,0.95))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
    y[i,1] <- mean(mcmc[,i])
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

h32 <- b2 <- list(NA)

for (i in 1:15){
h32[[i]] <- read.csv(paste("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1_oligotype/",i,"/mcmc_result1.csv",sep=""))
b2[[i]] <- read.csv(paste("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1_oligotype/",i,"/mcmc_result2.csv",sep=""))
}

h3 <- b <- matrix(NA,15,3)
for (i in 1:15){
temp1 <- para_summary(h32[[i]][10000+1:10000*2,],4,3,0)
temp2 <- para_summary(b2[[i]][10000+1:10000*2,],4,3,0)
h3[i,] <- as.matrix(temp1[22+i,1:3])
b[i,] <- as.matrix(temp2[22+i,1:3])
}


out <- round(cbind(exp(h3),exp(b)),2)
out2 <- cbind(paste(out[,1]," (",out[,2],", ",out[,3],")",sep=""),paste(out[,4]," (",out[,5],", ",out[,6],")",sep=""))

write.csv(out2,"/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/summary/tableS3.csv")

# 3 11 15 for a
# 2 7 8 for b


table1 <- log2(exp(h3))
table2 <- log2(exp(b))


### need to reverse
table1 <- table1[15:1,]
table2 <- table2[15:1,]

t1 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1_oligotype/3_15/mcmc_summary1.csv")
aa <- exp(t1)
table11 <- aa[22:36,2:4]

t1 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1_oligotype/2_6789/mcmc_summary2.csv")
aa <- exp(t1)
table21 <- aa[22:36,2:5]

table11 <- log2(table11)
table21 <- log2(table21)

table11[table11==0] <- 999999
table21[table21==0] <- 999999








pdf("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/summary/figure2b_new.pdf",width=10, height=8)

par(mar=c(4,25,1,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(-2,7), ylim=c(0,15),type="n")

cc <- 1:15-0.5

axis(1,at=-2:2,labels=2^(-2:2),cex.axis=1)
axis(2,at=c(-1.5,cc,17),labels=NA,las=1, pos=-2.2)


points(table1[,1],cc+0.08,pch=16,col="red",cex=0.8)
points(table2[,1],cc-0.08,pch=17,col="blue",cex=0.8)

for (i in 1:15){
  lines(table1[i,2:3],rep(cc[i]+0.08,2),col="red")  
  lines(table2[i,2:3],rep(cc[i]-0.08,2),col="blue")  
}

abline(v=0,lty=2)

# another panel
axis(1,at=-2:2+5,labels=2^(-2:2),cex.axis=1)
abline(v=0+5,lty=2)


points(table11[,1]+5,cc+0.08,pch=16,col="red",cex=0.8)
points(table21[,1]+5,cc-0.08,pch=17,col="blue",cex=0.8)

for (i in 1:15){
  lines(table11[i,2:3]+5,rep(cc[i]+0.08,2),col="red")  
  lines(table21[i,2:3]+5,rep(cc[i]-0.08,2),col="blue")  
}




mtext("Relative susceptibility",side=1,line=2.5)

se <- 0.15
cexpara <- 0.8

mtext(expression(italic("Veillonella dispar/atypica/")),side=2,line=1,at=14.5+se,las=1,cex=cexpara)
mtext(expression(italic("parvula/rogosae")),side=2,line=1,at=14.5-se,las=1,cex=cexpara)

mtext(expression(italic("Streptococcus vestibularis/")),side=2,line=1,at=13.5+se,las=1,cex=cexpara)
mtext(expression(italic("salivarius/gordoni/sp.")),side=2,line=1,at=13.5-se,las=1,cex=cexpara)

mtext(expression(italic("Streptococcus sp./dentisani/mitis/oralis/infantis/")),side=2,line=1,at=12.5+se,las=1,cex=cexpara)
mtext(expression(italic("tigurinus/lactarius/peroris/pneumoniae")),side=2,line=1,at=12.5-se,las=1,cex=cexpara)

mtext(expression(italic("Prevotella melaninogenica/scopos/")),side=2,line=1,at=11.5+se,las=1,cex=cexpara)
mtext(expression(italic("sp./histicola/veroralis")),side=2,line=1,at=11.5-se,las=1,cex=cexpara)

mtext(expression(italic("Prevotella histicola/sp./veroralis/")),side=2,line=1,at=10.5+se,las=1,cex=cexpara)
mtext(expression(italic("scopos/fusca/melaninogenica")),side=2,line=1,at=10.5-se,las=1,cex=cexpara)

mtext(expression(italic("Neisseria subflava/flavescens/flava/sicca/pharyngis/")),side=2,line=1,at=9.5+se,las=1,cex=cexpara)
mtext(expression(italic("mucosa/polysaccharea/weaveri/meningitidis/lactamica")),side=2,line=1,at=9.5-se,las=1,cex=cexpara)

mtext(expression(italic("Prevotella sp./veroralis/fusca/")),side=2,line=1,at=8.5+se,las=1,cex=cexpara)
mtext(expression(italic("histicola/scopos/melaninogenica")),side=2,line=1,at=8.5-se,las=1,cex=cexpara)

mtext(expression(italic("Haemophilus parainfluenzae/parahaemolyticus/paraphrohaemolyticus/")),side=2,line=1,at=7.5+se,las=1,cex=cexpara)
mtext(expression(italic("sputorum/sp./haemolyticus/influenzae")),side=2,line=1,at=7.5-se,las=1,cex=cexpara)

mtext(expression(italic("Fusobacterium periodonticum/")),side=2,line=1,at=6.5+se,las=1,cex=cexpara)
mtext(expression(italic("nucleatum/sp./naviforme")),side=2,line=1,at=6.5-se,las=1,cex=cexpara)

mtext(expression(italic("Prevotella sp./veroralis/")),side=2,line=1,at=5.5+se,las=1,cex=cexpara)
mtext(expression(italic("histicola/fusca/scopos")),side=2,line=1,at=5.5-se,las=1,cex=cexpara)

mtext(expression(italic("Gemella haemolysans/sanguinis/")),side=2,line=1,at=4.5+se,las=1,cex=cexpara)
mtext(expression(italic("morbillorum/bergeri")),side=2,line=1,at=4.5-se,las=1,cex=cexpara)

mtext(expression(italic("Veillonella parvula/rogosae/")),side=2,line=1,at=3.5+se,las=1,cex=cexpara)
mtext(expression(italic("atypica/denticariosi/dispar")),side=2,line=1,at=3.5-se,las=1,cex=cexpara)

mtext(expression(italic("Streptococcus australis/parasanguinis II/parasanguinis I/sp./oligofermentans/")),side=2,line=1,at=2.5+se,las=1,cex=cexpara)
mtext(expression(italic("cristatus/sinensis/sanguinis/gordonii/lactarius/peroris/oralis")),side=2,line=1,at=2.5-se,las=1,cex=cexpara)

mtext(expression(italic("Megasphaera micronuciformis")),side=2,line=1,at=1.5,las=1,cex=cexpara)

mtext(expression(italic("Prevotella salivae")),side=2,line=1,at=0.5,las=1,cex=cexpara)

legend(13,2, cex=0.7, legend=c("A(H3N2)","B"),lty=1,pch=c(16,17),col=c("red","blue"),bty="n")

#title(main="A", adj=0)
mtext("Step 1",side=3,cex=1,line=0, at=0)
mtext("Step 2",side=3,cex=1,line=0, at=5)

legend(5.5,14.5, cex=0.7, legend=c("A(H3N2)","B"),lty=1,pch=c(16,17),col=c("red","blue"),bty="n")

mtext("A",side=3,cex=1,line=0,at=-2.5)
mtext("B",side=3,cex=1,line=0,at=2.5)
dev.off()






### read the muplitle to see what happen



 