
library(chron)

h3 <- read.csv("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/mcmc_summary1.csv")
b <- read.csv("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/mcmc_summary2.csv")

table1 <- log2(exp(h3))
table2 <- log2(exp(b))

pdf("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/summary/figure2.pdf",width=6, height=3.8)

layout(matrix( 1, nrow=1,byrow=T))

par(mar=c(4,4,1,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,3), ylim=c(-4,4),type="n")

axis(1,at=c(-1,0.5,1.5,2.5,4),labels=c(NA,"Children","Vaccinated","Household size > 4",NA))
axis(2,at=-4:4,labels=2^(-4:4),las=1, pos=-0.05)

points(c(0.3,1.3,2.3),table1[c(8:9,21),2],pch=16,col="red")
points(c(0.7,1.7,2.7),table2[c(8:9,21),2],pch=17,col="blue")
lines(rep(0.3,2),pmax(table1[8,3:4],-4),col="red")
lines(rep(1.3,2),pmax(table1[9,3:4],-4),col="red")
lines(rep(2.3,2),pmax(table1[21,3:4],-4),col="red")
lines(rep(0.7,2),pmax(table2[8,3:4],-4),col="blue")
lines(rep(1.7,2),pmax(table2[9,3:4],-4),col="blue")
lines(rep(2.7,2),pmax(table2[21,3:4],-4),col="blue")

arrows(1.3,-3.7,1.3,-4,col="red",length=0.05)
arrows(1.7,-3.7,1.7,-4,col="blue",length=0.05)

abline(h=0,lty=2)

mtext("Relative risk",side=2,line=3)


legend(2.5,4, cex=0.7, legend=c("A(H3N2)","B"),lty=1,pch=c(16,17),col=c("red","blue"),bty="n")

mtext("(Ref: Adults)",side=1,cex=1,at=0.5,line=2.5)
mtext("(Ref: Unvaccinated)",side=1,cex=1,at=1.5,line=2.5)
mtext("(Ref: Size 2-4)",side=1,cex=1,at=2.5,line=2.5)

#title(main="A", adj=0)



dev.off()







