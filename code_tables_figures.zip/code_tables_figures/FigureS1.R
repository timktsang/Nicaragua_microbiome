
library(chron)

data1 <- as.matrix(read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1_oligotype/2018_06_09_data.csv"))
data2 <- as.matrix(read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1_oligotype/2018_06_09_prob.csv"))
data3 <- as.matrix(read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1_oligotype/2018_06_09_oligotype.csv"))

p1 <- data3[data1[,3]==2,-c(1:15)]
p2 <- data3[data1[,3]==3,-c(1:15)]

p11 <- p1[,1:15]
p21 <- p2[,1:15]

for (i in 1:14){
p11 <- rbind(p11,p1[,1:15+15*i])  
p21 <- rbind(p21,p2[,1:15+15*i])  
}

p11 <- p11[p11[,1]!=-1,]
p21 <- p21[p21[,1]!=-1,]

########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
    y[i,1] <- mean(mcmc[,i])
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}

p11 <- 10^p11
p21 <- 10^p21


table1 <- table2 <- matrix(NA,15,5)

for (i in 1:15){
table1[i,] <- quantile(p11[,i],c(0,0.25,0.5,0.75,1))
table2[i,] <- quantile(p21[,i],c(0,0.25,0.5,0.75,1))  
}


pdf("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/summary/figureS1.pdf",width=7.2, height=8)

par(mar=c(4,25,1,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(-2,6), ylim=c(0,16),type="n")

cc <- 1:15-0.5

axis(1,at=(-2):6,labels=2^c(-2,NA,0,NA,2,NA,4,NA,6),cex.axis=1)
axis(2,at=c(-1.5,cc,14.5),labels=NA,las=1, pos=-2.2)

i=3
points(log2(table1[,i]),cc+0.15,pch=16,col="red",cex=0.8)
points(log2(table2[,i]),cc-0.15,pch=17,col="blue",cex=0.8)


for (i in 1:15){
 lines(pmax(-1.9,log2(table1[i,c(1,5)])),rep(cc[i]+0.15,2),col="red")  
  lines(pmax(-1.9,log2(table2[i,c(1,5)])),rep(cc[i]-0.15,2),col="blue")  
}


mtext("Abundance (%)",side=1,line=2.5)

se <- 0.15
cexpara <- 0.8

mtext(expression(italic("Veillonella dispar/atypica/")),side=2,line=1,at=14.5+se,las=1,cex=cexpara)
mtext(expression(italic("parvula/rogosae")),side=2,line=1,at=14.5-se,las=1,cex=cexpara)

mtext(expression(italic("Streptococcus vestibularis/")),side=2,line=1,at=13.5+se,las=1,cex=cexpara)
mtext(expression(italic("salivarius/gordoni/sp.")),side=2,line=1,at=13.5-se,las=1,cex=cexpara)

mtext(expression(italic("Streptococcus sp./dentisani/mitis/oralis/infantis/")),side=2,line=1,at=12.5+se,las=1,cex=cexpara)
mtext(expression(italic("tigurinus/lactarius/peroris/pneumoniae")),side=2,line=1,at=12.5-se,las=1,cex=cexpara)

mtext(expression(italic("Prevotella melaninogenica/scopos/")),side=2,line=1,at=11.5+se,las=1,cex=cexpara)
mtext(expression(italic("sp./histicola/veroralis")),side=2,line=1,at=11.5-se,las=1,cex=cexpara)

mtext(expression(italic("Prevotella histicola/sp./veroralis/")),side=2,line=1,at=10.5+se,las=1,cex=cexpara)
mtext(expression(italic("scopos/fusca/melaninogenica")),side=2,line=1,at=10.5-se,las=1,cex=cexpara)

mtext(expression(italic("Neisseria subflava/flavescens/flava/sicca/pharyngis/")),side=2,line=1,at=9.5+se,las=1,cex=cexpara)
mtext(expression(italic("mucosa/polysaccharea/weaveri/meningitidis/lactamica")),side=2,line=1,at=9.5-se,las=1,cex=cexpara)

mtext(expression(italic("Prevotella sp./veroralis/fusca/")),side=2,line=1,at=8.5+se,las=1,cex=cexpara)
mtext(expression(italic("histicola/scopos/melaninogenica")),side=2,line=1,at=8.5-se,las=1,cex=cexpara)

mtext(expression(italic("Haemophilus parainfluenzae/parahaemolyticus/paraphrohaemolyticus/")),side=2,line=1,at=7.5+se,las=1,cex=cexpara)
mtext(expression(italic("sputorum/sp./haemolyticus/influenzae")),side=2,line=1,at=7.5-se,las=1,cex=cexpara)

mtext(expression(italic("Fusobacterium periodonticum/")),side=2,line=1,at=6.5+se,las=1,cex=cexpara)
mtext(expression(italic("nucleatum/sp./naviforme")),side=2,line=1,at=6.5-se,las=1,cex=cexpara)

mtext(expression(italic("Prevotella sp./veroralis/")),side=2,line=1,at=5.5+se,las=1,cex=cexpara)
mtext(expression(italic("histicola/fusca/scopos")),side=2,line=1,at=5.5-se,las=1,cex=cexpara)

mtext(expression(italic("Gemella haemolysans/sanguinis/")),side=2,line=1,at=4.5+se,las=1,cex=cexpara)
mtext(expression(italic("morbillorum/bergeri")),side=2,line=1,at=4.5-se,las=1,cex=cexpara)

mtext(expression(italic("Veillonella parvula/rogosae/")),side=2,line=1,at=3.5+se,las=1,cex=cexpara)
mtext(expression(italic("atypica/denticariosi/dispar")),side=2,line=1,at=3.5-se,las=1,cex=cexpara)

mtext(expression(italic("Streptococcus australis/parasanguinis II/parasanguinis I/sp./oligofermentans/")),side=2,line=1,at=2.5+se,las=1,cex=cexpara)
mtext(expression(italic("cristatus/sinensis/sanguinis/gordonii/lactarius/peroris/oralis")),side=2,line=1,at=2.5-se,las=1,cex=cexpara)

mtext(expression(italic("Megasphaera micronuciformis")),side=2,line=1,at=1.5,las=1,cex=cexpara)

mtext(expression(italic("Prevotella salivae")),side=2,line=1,at=0.5,las=1,cex=cexpara)

legend(0,16, cex=0.7, legend=c("A(H3N2)","B"),lty=1,pch=c(16,17),col=c("red","blue"),bty="n")

#title(main="A", adj=0)
#mtext("Abundance",side=3,cex=1,line=0)


dev.off()

