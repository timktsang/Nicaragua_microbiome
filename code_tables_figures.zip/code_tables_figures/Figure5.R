
library(chron)


########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
    y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
    y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
    y[i,1] <- mean(mcmc[,i])
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
    for (i in 1:ncol(mcmc)){
      plot(mcmc[,i],type="l")
    }
  }
  return(y)
}


setwd("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1")

data1 <- as.matrix(read.csv("2018_04_18_data.csv"))
data1[data1[,1]==135,4] <- 817
data1[data1[,1]==127,4] <- 810

AR1 <- matrix(NA,2,13)

aa <- data1[data1[,3]==2,]
i <- 1
AR1[i,1] <- sum((aa[,16+0:15*10]==1)*(aa[,21+0:15*10]<18))/sum((aa[,16+0:15*10]>=0)*(aa[,21+0:15*10]<18))
AR1[i,2] <- sum((aa[,16+0:15*10]==1)*(aa[,21+0:15*10]>=18))/sum((aa[,16+0:15*10]>=0)*(aa[,21+0:15*10]>=18))

AR1[i,3] <- sum((aa[,16+0:15*10]==1)*(aa[,23+0:15*10]==1))/sum((aa[,16+0:15*10]>=0)*(aa[,23+0:15*10]==1))
AR1[i,4] <- sum((aa[,16+0:15*10]==1)*(aa[,23+0:15*10]==0))/sum((aa[,16+0:15*10]>=0)*(aa[,23+0:15*10]==0))

AR1[i,5] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==1))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==1))
AR1[i,6] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==2))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==2))
AR1[i,7] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==3))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==3))
AR1[i,8] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==4))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==4))
AR1[i,9] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==5))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==5))

AR1[i,10] <- sum((aa[,16+0:15*10]==1)*(aa[,14]-aa[,7]<=2))/sum((aa[,16+0:15*10]>=0)*(aa[,14]-aa[,7]<=2))
AR1[i,11] <- sum((aa[,16+0:15*10]==1)*(aa[,14]-aa[,7]>2))/sum((aa[,16+0:15*10]>=0)*(aa[,14]-aa[,7]>2))

AR1[i,12] <- sum((aa[,16+0:15*10]==1)*(aa[,2]<=4))/sum((aa[,16+0:15*10]>=0)*(aa[,2]<=4))
AR1[i,13] <- sum((aa[,16+0:15*10]==1)*(aa[,2]>=5))/sum((aa[,16+0:15*10]>=0)*(aa[,5]>=5))


aa <- data1[data1[,3]==3,]
i <- 2
AR1[i,1] <- sum((aa[,16+0:15*10]==1)*(aa[,21+0:15*10]<18))/sum((aa[,16+0:15*10]>=0)*(aa[,21+0:15*10]<18))
AR1[i,2] <- sum((aa[,16+0:15*10]==1)*(aa[,21+0:15*10]>=18))/sum((aa[,16+0:15*10]>=0)*(aa[,21+0:15*10]>=18))

AR1[i,3] <- sum((aa[,16+0:15*10]==1)*(aa[,23+0:15*10]==1))/sum((aa[,16+0:15*10]>=0)*(aa[,23+0:15*10]==1))
AR1[i,4] <- sum((aa[,16+0:15*10]==1)*(aa[,23+0:15*10]==0))/sum((aa[,16+0:15*10]>=0)*(aa[,23+0:15*10]==0))

AR1[i,5] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==1))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==1))
AR1[i,6] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==2))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==2))
AR1[i,7] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==3))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==3))
AR1[i,8] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==4))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==4))
AR1[i,9] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==5))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==5))

AR1[i,10] <- sum((aa[,16+0:15*10]==1)*(aa[,14]-aa[,7]<=2))/sum((aa[,16+0:15*10]>=0)*(aa[,14]-aa[,7]<=2))
AR1[i,11] <- sum((aa[,16+0:15*10]==1)*(aa[,14]-aa[,7]>2))/sum((aa[,16+0:15*10]>=0)*(aa[,14]-aa[,7]>2))

AR1[i,12] <- sum((aa[,16+0:15*10]==1)*(aa[,2]<=4))/sum((aa[,16+0:15*10]>=0)*(aa[,2]<=4))
AR1[i,13] <- sum((aa[,16+0:15*10]==1)*(aa[,2]>=5))/sum((aa[,16+0:15*10]>=0)*(aa[,5]>=5))



obs <- AR1

h32 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1/AR1.csv")
b2 <- read.csv("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1/AR2.csv")

h3 <- para_summary(h32,4,3,0)
b <- para_summary(b2,4,3,0)

AR1 <- AR1[,-(10:11)]
h3 <- h3[-(10:11),]
b <- b[-(10:11),]


pdf("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/summary/figure5_test.pdf",width=11.5, height=7.75)

layout(matrix( 1:2, nrow=2,byrow=T))


par(mar=c(5,4,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,14), ylim=c(0,0.5),type="n")

cc <- c(0.5,1.5,3.5,4.5,6.5,7.5,8.5,9.5,10.5,12.5,13.5) 

axis(1,at=c(-0.5,cc,15),labels=c(NA,"Children","Adults","Yes","No","Type 1","Type 2","Type 3","Type 4","Type 5","2-4",">4",NA),cex.axis=1)
axis(2,at=0:5*0.1,labels=0:5*0.1,las=1, pos=-0.5)

points(cc-0.15,AR1[1,],pch=16,col="orange")
points(cc+0.15,h3[,1],pch=17,col="purple")

for (i in 1:11){
  lines(rep(cc[i]+0.15,2),h3[i,2:3],col="purple")  
}

#points(c(0.3,1.3),table1[8:9,2],pch=16,col="red")
#points(c(0.7,1.7),table2[8:9,2],pch=17,col="blue")
#lines(rep(0.3,2),pmax(table1[8,3:4],-4),col="red")
#lines(rep(1.3,2),pmax(table1[9,3:4],-4),col="red")
#lines(rep(0.7,2),pmax(table2[8,3:4],-4),col="blue")
#lines(rep(1.7,2),pmax(table2[9,3:4],-4),col="blue")


mtext("Risk of infection",side=2,line=3)


legend(12.5,0.55, cex=1, legend=c("Observed","Predicted"),pch=c(16,17),col=c("orange","purple"),bty="n")

mtext("Age groups",side=1,cex=1,at=1,line=2.5)
mtext("Vaccination",side=1,cex=1,at=4,line=2.5)
mtext("Community type",side=1,cex=1,at=8.5,line=2.5)
mtext("Household size",side=1,cex=1,at=13,line=2.5)

title(main="A", adj=0)
mtext("Influenza A(H3N2)",side=3,cex=1,line=0.5)


#######
## B


par(mar=c(5,4,2,1))

plot(0,0,xlab="",ylab="", main="", axes=F, xlim=c(0,14), ylim=c(0,0.5),type="n")

cc <- c(0.5,1.5,3.5,4.5,6.5,7.5,8.5,9.5,10.5,12.5,13.5) 

axis(1,at=c(-0.5,cc,15),labels=c(NA,"Children","Adults","Yes","No","Type 1","Type 2","Type 3","Type 4","Type 5","2-4",">4",NA),cex.axis=1)
axis(2,at=0:5*0.1,labels=0:5*0.1,las=1, pos=-0.5)

points(cc-0.15,AR1[2,],pch=16,col="orange")
points(cc+0.15,b[,1],pch=17,col="purple")

for (i in 1:11){
  lines(rep(cc[i]+0.15,2),b[i,2:3],col="purple")  
}

#points(c(0.3,1.3),table1[8:9,2],pch=16,col="red")
#points(c(0.7,1.7),table2[8:9,2],pch=17,col="blue")
#lines(rep(0.3,2),pmax(table1[8,3:4],-4),col="red")
#lines(rep(1.3,2),pmax(table1[9,3:4],-4),col="red")
#lines(rep(0.7,2),pmax(table2[8,3:4],-4),col="blue")
#lines(rep(1.7,2),pmax(table2[9,3:4],-4),col="blue")


mtext("Risk of infection",side=2,line=3)


#legend(9.5,0.6, cex=0.7, legend=c("Observed","Predicted"),pch=c(16,17),col=c("orange","purple"),bty="n")

mtext("Age groups",side=1,cex=1,at=1,line=2.5)
mtext("Vaccination",side=1,cex=1,at=4,line=2.5)
mtext("Community type",side=1,cex=1,at=8.5,line=2.5)
mtext("Household size",side=1,cex=1,at=13,line=2.5)

title(main="B", adj=0)
mtext("Influenza B",side=3,cex=1,line=0.5)




dev.off()





