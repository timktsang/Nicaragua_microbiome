#!/bin/bash
#SBATCH --job-name='community_type'
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --cpus-per-task=8
#SBATCH --mem=8gb
#SBATCH --time=90:00:00
#SBATCH --account=epi
#SBATCH --qos=epi-b

pwd; hostname; date

cat /proc/cpuinfo

module load R

Rscript community_type.r 

date
