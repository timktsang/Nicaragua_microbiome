#include <RcppArmadilloExtensions/sample.h>
#include <Rcpp.h>
#include <RcppParallel.h>
// [[Rcpp::depends(RcppArmadillo)]]
// [[Rcpp::depends(RcppParallel)]]
using namespace Rcpp ;
using namespace RcppParallel;

//########################################################################################################################################
//function for computing the serial interval density
// [[Rcpp::export]]
NumericVector serial_density(double p1,
double p2){
NumericVector a=NumericVector::create(1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0,10.0,11.0,12.0,13.0,14.0);
return (pweibull(a+1,p1,p2)-pweibull(a,p1,p2));
}

//########################################################################################################################################
// function to generate normal random variable
// [[Rcpp::export]]
double rnorm(double a, double b) { // a: mean, b: s.d.
	double c=a+b*sum(rnorm(1));
    return c;
}

//########################################################################################################################################
// function to generate binomial random number
// [[Rcpp::export]]
int gen_binom(double p){
double cut=(double)rand()/(RAND_MAX);
int out=0;
if (cut<p){
out=1;
}
return out;
}

//########################################################################################################################################
// function to general multiviariable normal given sigma
// [[Rcpp::export]]
NumericVector rmnorm(arma::mat sigma) {
int ncols=sigma.n_cols;
arma::rowvec c=arma::randn(1,ncols);
arma::rowvec a=c*arma::chol(sigma);   
NumericVector b=NumericVector(a.begin(),a.end());   
return b;
}

//########################################################################################################################################
//function to compute the prior likelihood 
// [[Rcpp::export]]
double prior_loglik(NumericVector para){
// check if the para are within their possible range
int b1;
double out=1;
for (b1=3;b1>=0;--b1){
out*=sum(dunif(NumericVector::create(para(b1)),0.001,10.0));
}
for (b1=35;b1>=4;--b1){
out*=sum(dunif(NumericVector::create(para(b1)),-10.0,10.0));
}
// if the prior is outside the parameter space
if ((out==0)||(sum(serial_density(para[0],para[1]))<0.8)){
out=-9999999;
}
else{
out=log(out);	
}
return out;
}



//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for doing simulation
struct SimData:public Worker{
// source vector
RMatrix<int> data11;
RMatrix<int> data1;
RMatrix<double> data3;
RVector<double> para;
RVector<double> SI;
int sep1;
int sep2;
RMatrix<int> record;
// destination vector
// initialize with source and destination
SimData(IntegerMatrix data11,
IntegerMatrix data1,
NumericMatrix data3,
NumericVector para,
NumericVector SI,
int sep1,
int sep2,
IntegerMatrix record) 
:data11(data11),data1(data1),data3(data3),para(para),SI(SI),sep1(sep1),sep2(sep2),record(record){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)

for (unsigned int b1=begin;b1<end;++b1){	
int b2;
int b3;
int b4;
double hazard;
double sus[data11(b1,1)];

// first set every household contacts have 0 infection status
for (b2=data11(b1,1)-1;b2>=1;--b2){
// initial point to set all people is uninfected at the beginning	
data11(b1,b2*sep2+sep1)=0;
data11(b1,b2*sep2+sep1+1)=-1;
// add factor affecting transmission
//# 3: community para
//# 4: household para
//# 5: H1 vs H3
//# 6: B vs H3
//# 7: Age <=18, flu A
//# 8: Age <=18, flu B
//# 9: vaccination
//# 10: community type 2
//# 11: community type 3
//# 12: community type 4
//# 13: community type 5
//# 14: age inf
//# 15: antiviral treatment inf
//# 16: community type 2 inf
//# 17: community type 3 inf 
//# 18: community type 4 inf
//# 19: community type 5 inf
//# 20: household size 6-7
//# 21: household size >7

// data
//## 1. hhID, 2.size, 3 influenza type ,4-5: follow start and end date 
//## 5 + 1. infectious status, 2. infection time, 3,4.start and end of follow-up 5.id 
//## 6.age, 7.sex, 8.vaccination, 9.oseltamivir treatment, 10.community type
sus[b2]=0;
// age
//sus[b2]+=para[6]*(data11(b1,b2*sep2+sep1+5)<=5);
sus[b2]+=para[7]*(data11(b1,b2*sep2+sep1+5)<=17);
// vac
sus[b2]+=para[8]*(data11(b1,b2*sep2+sep1+7)==1);
// community type
sus[b2]+=para[9]*(data11(b1,b2*sep2+sep1+9)==2);
sus[b2]+=para[10]*(data11(b1,b2*sep2+sep1+9)==3);
sus[b2]+=para[11]*(data11(b1,b2*sep2+sep1+9)==4);
sus[b2]+=para[12]*(data11(b1,b2*sep2+sep1+9)==5);
sus[b2]+=para[13]*(data11(b1,sep1+5)<=17);
sus[b2]+=para[14]*((data11(b1,sep1+8)>0)&&(data11(b1,sep1+8)-data11(b1,sep1+1)<=2));
sus[b2]+=para[20]*(data11(b1,1)>=5);
for (b3=14;b3>=0;--b3){
sus[b2]+=para[21+b3]*(data3(b1,b2*15+b3));
}
}


// first need to have a time index
for (b2=data11(b1,3)+1;b2<=data11(b1,4);++b2){
// participant index
// index case do not need update
for (b3=data11(b1,1)-1;b3>=1;--b3){
if (data11(b1,b3*sep2+sep1)==0){
// compute the community hazard
hazard=para[2];
// compute the household hazard
for (b4=data11(b1,1)-1;b4>=0;--b4){
if ((b4!=b3)&&(data11(b1,b4*sep2+sep1)==1)){
// need to with the range of serial interval to have contribution
if ((b2-data11(b1,b4*sep2+sep1+1)>0)&&(b2-data11(b1,b4*sep2+sep1+1)<=14)){
double hrisk=para[3];	
// here need to add factor affecting infectivity
//hrisk*=exp(para[4]*(data11(b1,2)==1));
//hrisk*=exp(para[5]*(data11(b1,2)==3));
//hrisk*=exp(para[13]*(data11(b1,b4*sep2+sep1+5)<=5));
//hrisk*=exp(para[14]*((data11(b1,b4*sep2+sep1+8)>0)&&(data11(b1,b4*sep2+sep1+8)-data11(b1,b4*sep2+sep1+1)<=2)));
//hrisk*=exp(para[15]*(data11(b1,b4*sep2+sep1+9)==2));
//hrisk*=exp(para[16]*(data11(b1,b4*sep2+sep1+9)==3));
//hrisk*=exp(para[17]*(data11(b1,b4*sep2+sep1+9)==4));
//hrisk*=exp(para[18]*(data11(b1,b4*sep2+sep1+9)==5));
//hrisk*=exp(para[19]*(data11(b1,1)>=6&&data11(b1,1)<=7));
//hrisk*=exp(para[20]*(data11(b1,1)>7));
hazard+=hrisk*SI[b2-data11(b1,b4*sep2+sep1+1)-1]; // need to -1 beacuse the index is from 0 to 9
}
}	
}
// then need to add factor affecting transmission
hazard*=exp(sus[b3]);
// generate infeciton
// infection
if (gen_binom(1-exp(-hazard))){	
data11(b1,b3*sep2+sep1)=1;
data11(b1,b3*sep2+sep1+1)=b2;
}
}
}
}




}
}
};

//########################################################################################################################################
//function to do simulation
// [[Rcpp::export]]
List sim_data(IntegerMatrix data1,
NumericMatrix data2,
NumericMatrix data3,
NumericVector para,
int sep1,      // sep1=5
int sep2){     // sep2=10
int b1;
int b2;
int b3;
// clone the data first
IntegerMatrix data11(clone(data1));

IntegerMatrix record(data11.nrow(),8);

// here simulate the missing community types

NumericVector prob(5);

for (b1=data11.nrow()-1;b1>=0;--b1){
for (b2=data11(b1,1)-1;b2>=0;--b2){
if (data11(b1,b2*sep2+sep1+9)==-1){

for (b3=4;b3>=0;--b3){
prob(b3)=data2(b1,b2*5+b3);	
}

double simvalue=(double)rand()/(RAND_MAX);
//record_mcmc1(b0,3)=simvalue;
simvalue*=sum(prob);
for (b3=4;b3>=0;--b3){
simvalue-=prob(b3);
if (simvalue<0){
data11(b1,b2*sep2+sep1+9)=b3+1;
break;
}
}

}
}
}



//1. hhID, 2.size, 3 influenza type ,4-5: follow start and end date 
//5 + 1. infectious status, 2. infection time, 3,4.start and end of follow-up 5.id 
//6.age, 7.sex, 8.vaccination, 9.oseltamivir treatment, 10.community type

// compute the serial_density to use
NumericVector SI=serial_density(para[0],para[1]);

// call parallel program
SimData simdata1(data11,data1,data3,para,SI,sep1,sep2,record);

// call parallelFor to do the work
parallelFor(0,data1.nrow(),simdata1);


return List::create(_[""]=data11,
_[""]=record);
} 


//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for Digraphlikelihood
struct LogLik:public Worker{
// source vector
RMatrix<double> out;
RMatrix<int> data;
RMatrix<double> data3;
RVector<double> para;
RVector<double> SI;
int sep1;
int sep2;
RMatrix<double> record;
// destination vector
// initialize with source and destination
LogLik(NumericMatrix out,
IntegerMatrix data,
NumericMatrix data3,
NumericVector para,
NumericVector SI,
int sep1,
int sep2,
NumericMatrix record) 
:out(out),data(data),data3(data3),para(para),SI(SI),sep1(sep1),sep2(sep2),record(record){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){
int b2;
int b3;
int b4;
int b5;

// b3 is the participant index
for (b3=data(b1,1)-1;b3>=1;--b3){
if (!((data(b1,b3*sep2+sep1)==1)&(data(b1,b3*sep2+sep1+1)==data(b1,sep1+1)))){
// need to add factor addecting susceptibility
double sus=0;
//sus+=para[6]*(data(b1,b3*sep2+sep1+5)<=5);
sus+=para[7]*(data(b1,b3*sep2+sep1+5)<=17);
// vac
sus+=para[8]*(data(b1,b3*sep2+sep1+7)==1);
// community type
sus+=para[9]*(data(b1,b3*sep2+sep1+9)==2);
sus+=para[10]*(data(b1,b3*sep2+sep1+9)==3);
sus+=para[11]*(data(b1,b3*sep2+sep1+9)==4);
sus+=para[12]*(data(b1,b3*sep2+sep1+9)==5);
sus+=para[4]*(data(b1,2)==1);
sus+=para[5]*(data(b1,2)==3);
sus+=para[13]*(data(b1,sep1+5)<=17);
sus+=para[14]*((data(b1,sep1+8)>0)&&(data(b1,sep1+8)-data(b1,sep1+1)<=2));
sus+=para[15]*(data(b1,sep1+9)==2);
sus+=para[16]*(data(b1,sep1+9)==3);
sus+=para[17]*(data(b1,sep1+9)==4);
sus+=para[18]*(data(b1,sep1+9)==5);
sus+=para[19]*(data(b1,1)>=6&&data(b1,1)<=7);
sus+=para[20]*(data(b1,1)>=5);
for (b2=14;b2>=0;--b2){
sus+=para[21+b2]*(data3(b1,b3*15+b2));
}
// the final date for contribution from non-infection
int finaltime=data(b1,4)+1;
if (data(b1,b3*sep2+sep1)==1){
finaltime=data(b1,b3*sep2+sep1+1);	
}

double h[finaltime-data(b1,3)];
// fill the community risk
for (b2=finaltime-data(b1,3)-1;b2>=0;--b2){
h[b2]=para[2];	
}


for (b4=data(b1,1)-1;b4>=0;--b4){
if ((b4!=b3)&&(data(b1,b4*sep2+sep1)==1)){
for (b5=13;b5>=0;--b5){
//if (data(b1,b4*sep2+sep1+1)+b5<=data(b1,4)){
// if infection date of individual b3 is smaller than the final time	
if (data(b1,b4*sep2+sep1+1)+b5+1<=finaltime){ 
double hrisk=para[3];
// here need to add factor affecting infectivity
//hrisk*=exp(para[4]*(data(b1,2)==1));
//hrisk*=exp(para[5]*(data(b1,2)==3));
//hrisk*=exp(para[13]*(data(b1,b4*sep2+sep1+5)<=5));
//hrisk*=exp(para[14]*((data(b1,b4*sep2+sep1+8)>0)&&(data(b1,b4*sep2+sep1+8)-data(b1,b4*sep2+sep1+1)<=2)));
//hrisk*=exp(para[15]*(data(b1,b4*sep2+sep1+9)==2));
//hrisk*=exp(para[16]*(data(b1,b4*sep2+sep1+9)==3));
//hrisk*=exp(para[17]*(data(b1,b4*sep2+sep1+9)==4));
//hrisk*=exp(para[18]*(data(b1,b4*sep2+sep1+9)==5));
//hrisk*=exp(para[19]*(data(b1,1)<6));
//hrisk*=exp(para[20]*(data(b1,1)>7));
h[data(b1,b4*sep2+sep1+1)-data(b1,3)+b5]+=hrisk*SI[b5];
}
}
}	
}
//}


for (b2=finaltime-data(b1,3)-2;b2>=0;--b2){
out(b1,b3)-=h[b2]*exp(sus);	
}
if (data(b1,b3*sep2+sep1)==1){
out(b1,b3)+=log(1-exp(-h[finaltime-data(b1,3)-1]*exp(sus)));	
}

if (b3==1){
for (b2=finaltime-data(b1,3)-1;b2>=0;--b2){
record(b1,b2)=h[b2];
}
}

}
}

}
}
};

//########################################################################################################################################
//function to likelihood
// [[Rcpp::export]]
double loglik(IntegerMatrix data,
NumericMatrix data3,	
NumericVector para,
int sep1,
int sep2){
// check if the para are within their possible range
NumericMatrix out(data.nrow(),20);
NumericMatrix record(data.nrow(),20);
NumericVector SI=serial_density(para[0],para[1]);
// call parallel program
LogLik loglik(out,data,data3,para,SI,sep1,sep2,record);
// call parallelFor to do the work
parallelFor(0,data.nrow(),loglik);

return sum(out);
//return List::create(_[""]=out,
//	_[""]=record);

}



//########################################################################################################################################
//########################################################################################################################################
// the main body of the parallel for Digraphlikelihood
struct LogLikImpute:public Worker{
// source vector
RMatrix<int> out;
RMatrix<int> data;
RMatrix<double> data2;
RMatrix<double> data3;
RVector<double> para;
RVector<double> SI;
int sep1;
int sep2;
RMatrix<int> imputematrix;
RMatrix<double> record;
// destination vector
// initialize with source and destination
LogLikImpute(IntegerMatrix out,
IntegerMatrix data,
NumericMatrix data2,
NumericMatrix data3,
NumericVector para,
NumericVector SI,
int sep1,
int sep2,
IntegerMatrix imputematrix,
NumericMatrix record) 
:out(out),data(data),data2(data2),data3(data3),para(para),SI(SI),sep1(sep1),sep2(sep2),imputematrix(imputematrix),record(record){}
void operator()(std::size_t begin, std::size_t end) {

// section to write the parallel version
// functor (pass input and output matrixes)
for (unsigned int b1=begin;b1<end;++b1){
if (imputematrix(b1,0)!=0){
int b2;
int b3;
int b4;
int b5;
int b6;

int select=0;
int member=0;
// get the index, i.e, compute b3
member=imputematrix(b1,0)-1;
if (imputematrix(b1,1)!=0){
select=rand()%2;
member=imputematrix(b1,select)-1;	
}

for (b6=4;b6>=0;--b6){
data(b1,member*sep2+sep1+9)=b6+1;	
// b3 is the participant index
for (b3=data(b1,1)-1;b3>=1;--b3){
// need to add factor addecting susceptibility
double sus=0;
//sus+=para[6]*(data(b1,b3*sep2+sep1+5)<=5);
sus+=para[7]*(data(b1,b3*sep2+sep1+5)<=17);
// vac
sus+=para[8]*(data(b1,b3*sep2+sep1+7)==1);
// community type
sus+=para[9]*(data(b1,b3*sep2+sep1+9)==2);
sus+=para[10]*(data(b1,b3*sep2+sep1+9)==3);
sus+=para[11]*(data(b1,b3*sep2+sep1+9)==4);
sus+=para[12]*(data(b1,b3*sep2+sep1+9)==5);
sus+=para[4]*(data(b1,2)==1);
sus+=para[5]*(data(b1,2)==3);
sus+=para[13]*(data(b1,sep1+5)<=17);
sus+=para[14]*((data(b1,sep1+8)>0)&&(data(b1,sep1+8)-data(b1,sep1+1)<=2));
sus+=para[15]*(data(b1,sep1+9)==2);
sus+=para[16]*(data(b1,sep1+9)==3);
sus+=para[17]*(data(b1,sep1+9)==4);
sus+=para[18]*(data(b1,sep1+9)==5);
sus+=para[19]*(data(b1,1)>=6&&data(b1,1)<=7);
sus+=para[20]*(data(b1,1)>=5);
for (b2=14;b2>=0;--b2){
sus+=para[21+b2]*(data3(b1,b3*15+b2));
}
// the final date for contribution from non-infection
int finaltime=data(b1,4)+1;
if (data(b1,b3*sep2+sep1)==1){
finaltime=data(b1,b3*sep2+sep1+1);	
}

double h[finaltime-data(b1,3)];
// fill the community risk
for (b2=finaltime-data(b1,3)-1;b2>=0;--b2){
h[b2]=para[2];	
}


for (b4=data(b1,1)-1;b4>=0;--b4){
if ((b4!=b3)&&(data(b1,b4*sep2+sep1)==1)){
for (b5=13;b5>=0;--b5){
//if (data(b1,b4*sep2+sep1+1)+b5<=data(b1,4)){
// if infection date of individual b3 is smaller than the final time	
if (data(b1,b4*sep2+sep1+1)+b5+1<=finaltime){ 
double hrisk=para[3];
// here need to add factor affecting infectivity
//hrisk*=exp(para[4]*(data(b1,2)==1));
//hrisk*=exp(para[5]*(data(b1,2)==3));
//hrisk*=exp(para[13]*(data(b1,b4*sep2+sep1+5)<=5));
//hrisk*=exp(para[14]*((data(b1,b4*sep2+sep1+8)>0)&&(data(b1,b4*sep2+sep1+8)-data(b1,b4*sep2+sep1+1)<=2)));
//hrisk*=exp(para[15]*(data(b1,b4*sep2+sep1+9)==2));
//hrisk*=exp(para[16]*(data(b1,b4*sep2+sep1+9)==3));
//hrisk*=exp(para[17]*(data(b1,b4*sep2+sep1+9)==4));
//hrisk*=exp(para[18]*(data(b1,b4*sep2+sep1+9)==5));
//hrisk*=exp(para[19]*(data(b1,1)<6));
//hrisk*=exp(para[20]*(data(b1,1)>7));
h[data(b1,b4*sep2+sep1+1)-data(b1,3)+b5]+=hrisk*SI[b5];
}
}
}	
}
//}

// record here is the likelihood of the community type
for (b2=finaltime-data(b1,3)-2;b2>=0;--b2){
record(b1,b6)-=h[b2]*exp(sus);	
}
if (data(b1,b3*sep2+sep1)==1){
record(b1,b6)+=log(1-exp(-h[finaltime-data(b1,3)-1]*exp(sus)));	
}
}
}

for (b6=4;b6>=0;--b6){
record(b1,b6)-=record(b1,0);
}
for (b6=4;b6>=0;--b6){
record(b1,b6)=exp(record(b1,b6))*(data2(b1,5*member+b6));	
}

double simvalue=(double)rand()/(RAND_MAX);
//record_mcmc1(b0,3)=simvalue;
simvalue*=(record(b1,0)+record(b1,1)+record(b1,2)+record(b1,3)+record(b1,4));
for (b6=4;b6>=0;--b6){
simvalue-=record(b1,b6);
if (simvalue<0){
out(b1,select)=b6+1;
break;
}
}


}

}
}
};

//########################################################################################################################################
//function to likelihood
// [[Rcpp::export]]
IntegerMatrix loglik_impute(IntegerMatrix data,
NumericMatrix data2,	
NumericMatrix data3,
NumericVector para,
int sep1,
int sep2,
IntegerMatrix imputematrix){
// check if the para are within their possible range
IntegerMatrix data1(clone(data));	
IntegerMatrix out(data.nrow(),2);
// record is used to record prob
NumericMatrix record(data.nrow(),5);
NumericVector SI=serial_density(para[0],para[1]);
// call parallel program
LogLikImpute loglikimpute(out,data1,data2,data3,para,SI,sep1,sep2,imputematrix,record);
// call parallelFor to do the work
parallelFor(0,data.nrow(),loglikimpute);

return out;
//return List::create(_[""]=out,
//	_[""]=record);

}

//##############################################################################################################################################
//##############################################################################################################################################
// function for mcmc
// [[Rcpp::export]]
List mcmc(IntegerMatrix data1,
NumericMatrix data2,
NumericMatrix data3,
int mcmc_n,             // length of mcmc stain
NumericVector int_para, // initial parameter
NumericVector move,     // which one should move in the model
NumericVector sigma){            

// create the vector for use
int b0;
int b1;
int b2;
int b3;
int b4;
int sep1=5;
int sep2=10;
int moveindex;

//####################################################################################################################################
// backup data 
IntegerMatrix data11(clone(data1));

// impute the community
IntegerMatrix imputematrix(data11.nrow(),2);

for (b1=data11.nrow()-1;b1>=0;--b1){
int countindex=0;
for (b2=data11(b1,1)-1;b2>=0;--b2){
if (data11(b1,b2*sep2+sep1+9)==-1){
imputematrix(b1,countindex)=b2+1;
++countindex;
data11(b1,b2*sep2+sep1+9)=rand()%5+1;
}
}
}


// matrix to record LL
// need to set number of parameter here
NumericMatrix p_para(mcmc_n,int_para.length());
NumericMatrix p_para_r(mcmc_n,sum(move));
p_para(0,_)=int_para;
moveindex=sum(move)-1;
for (b1=int_para.length()-1;b1>=0;--b1){
if (move(b1)){
p_para_r(0,moveindex)=p_para(0,b1);
--moveindex;
}	
}

// first row is the overall matrix, other three row is the indiviudal likelihood
NumericVector acceptrate(int_para.length());
NumericVector LL1(mcmc_n);
// serial interval record
NumericMatrix SIexp(mcmc_n,2);

//####################################################################################################################################
// initial step

//####################################################################################################################################
// compute likelihood


double loglik1=loglik(data11,data3,p_para(0,_),sep1,sep2);
double loglik1pro;

LL1(0)=loglik1;

double temploglik;
double newloglik;
temploglik=LL1(0)+prior_loglik(p_para(0,_));

double loglikeratio;
double accept_pro;
NumericVector pro_para(int_para.length());

NumericVector SIvec=serial_density(p_para(0,0),p_para(0,1));
for (b1=13;b1>=0;--b1){
SIexp(0,0)+=(b1+1)*SIvec(b1);
SIexp(0,1)+=(b1+1)*(b1+1)*SIvec(b1);
}


//####################################################################################################################################
// main mcmc step

//####################################################################################################################################
for (b0=1;b0<mcmc_n;++b0){

// after 500 step, then set the sigma to be the empirical sigma
if (b0>500){
for (b1=int_para.length()-1;b1>=0;--b1){
if (move(b1)){	
NumericVector temp1(b0-1);
for (b2=b0-2;b2>=0;--b2){
temp1(b2)=p_para(b2,b1);	
}
sigma(b1)=sd(temp1);
// tuning
if (acceptrate(b1)<0.1){
sigma(b1)*=0.5;
}	
if ((acceptrate(b1)<0.15)&(acceptrate(b1)>0.1)){
sigma(b1)*=0.8;
}
if ((acceptrate(b1)<0.2)&(acceptrate(b1)>0.15)){
sigma(b1)*=0.95;
}
if ((acceptrate(b1)<0.4)&(acceptrate(b1)>0.3)){
sigma(b1)*=1.05;
}
if ((acceptrate(b1)<0.9)&(acceptrate(b1)>0.4)){
sigma(b1)*=1.2;
}
if (acceptrate(b1)>0.9){
sigma(b1)*=2;
}
}
}
}

// metorpolis-hasing update on parameter
for (b1=0;b1<int_para.length();++b1){
if (move(b1)){
pro_para=p_para(b0-1,_);
for (b2=b1-1;b2>=0;--b2){
pro_para(b2)=p_para(b0,b2);	
}
pro_para(b1)+=rnorm(0.0,sigma(b1));
newloglik=prior_loglik(pro_para);
if (newloglik> -9999999){
loglik1pro=loglik(data11,data3,pro_para,sep1,sep2);
// recompute the susceptiblity matrix
newloglik+=loglik1pro;
loglikeratio=newloglik-temploglik;
accept_pro=pow(exp(1),loglikeratio);
}
else{
accept_pro=0;	
}
if(gen_binom(accept_pro)){
p_para(b0,b1)=pro_para(b1);
temploglik=newloglik;
loglik1=loglik1pro;
acceptrate(b1)*=(b0-1);
acceptrate(b1)+=1;
acceptrate(b1)/=b0;
}
else{
p_para(b0,b1)=p_para(b0-1,b1);
acceptrate(b1)*=(b0-1);
acceptrate(b1)/=b0;
}
}
else {
p_para(b0,b1)=p_para(b0-1,b1);
}
}

LL1(b0)=temploglik-prior_loglik(p_para(b0,_));

// move the matirx to another matrix to store the parameter and compute the correlation matrix
moveindex=sum(move)-1;
for (b1=int_para.length()-1;b1>=0;--b1){
if (move(b1)){
p_para_r(b0,moveindex)=p_para(b0,b1);
--moveindex;
}	
}

SIvec=serial_density(p_para(b0,0),p_para(b0,1));
for (b1=13;b1>=0;--b1){
SIexp(b0,0)+=(b1+1)*SIvec(b1);
SIexp(b0,1)+=(b1+1)*(b1+1)*SIvec(b1);
}

// based on the parameter, impute the community type
IntegerMatrix imputeresult;
imputeresult=loglik_impute(data11,data2,data3,p_para(b0,_),sep1,sep2,imputematrix);
for (b1=data11.nrow()-1;b1>=0;--b1){
for (b2=1;b2>=0;--b2){
if (imputeresult(b1,b2)>0){
data11(b1,(imputematrix(b1,b2)-1)*sep2+sep1+9)=imputeresult(b1,b2);
}
}
}

// update impute likelihood
LL1(b0)=loglik(data11,data3,p_para(b0,_),sep1,sep2);
temploglik=LL1(b0)+prior_loglik(p_para(b0,_));


if (b0%1000==0){
Rcout << b0 << std::endl;
}

}


return List::create(_[""]=p_para,
_[""]=LL1,
_[""]=SIexp,
_[""]=acceptrate,
_[""]=data11,
_[""]=imputematrix);
} 





