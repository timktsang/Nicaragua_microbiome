### program for community type analysis
rm(list = ls())

library(Rcpp)
library(RcppParallel)

########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
  y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
  y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
  for (i in 1:ncol(mcmc)){
  plot(mcmc[,i],type="l")
  }
  }
  return(y)
}

########

setwd("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp")
sourceCpp("community_type.cpp")

data1 <- as.matrix(read.csv("2018_04_18_data.csv"))
data1[data1[,1]==135,4] <- 817
data1[data1[,1]==127,4] <- 810

data2 <- as.matrix(read.csv("2018_04_18_prob.csv"))

#
simpara1 <- read.csv("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/mcmc_result1.csv")
simpara2 <- read.csv("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/mcmc_result2.csv")

simpara1 <- simpara1[10000+1:10000*2,-1]
simpara2 <- simpara2[10000+1:10000*2,-1]

# person-to-person risk of transmission in households
AR1 <- AR2 <- matrix(NA,10000,4)

# change data1 to h3 and data2 to b
data <- data1
data11 <- data[data[,3]==2,]
data21 <- data[data[,3]==3,]

data31 <- data2[data[,3]==2,]
data32 <- data2[data[,3]==3,]

impute1 <- matrix(NA,11,2)
impute2 <- matrix(NA,9,2)

index <- 1
for (i in 1:nrow(data11)){
for (j in 1:data11[i,2]){
if (data11[i,j*10+11]!=-1&data11[i,j*10+15]==-1){
impute1[index,1:2] <- c(i,j)
index <- index + 1
}
}  
}

index <- 1
for (i in 1:nrow(data21)){
  for (j in 1:data21[i,2]){
    if (data21[i,j*10+11]!=-1&data21[i,j*10+15]==-1){
      impute2[index,1:2] <- c(i,j)
      index <- index + 1
    }
  }  
}


for (i in 1:10000){
data1 <- data11  
for (j in 1:nrow(impute1)){
data1[impute1[j,1],impute1[j,2]*10+15]  <- sample(1:5,1,replace=F,data31[impute1[j,1],impute1[j,2]*5+1:5]) 
}

a1 <- ((data1[,11+1:16*10]<18&data1[,11+1:16*10]>=0)*simpara1[i,8]+(data1[,13+1:16*10]==1)*simpara1[i,9]
       +(data1[,15+1:16*10]==2)*simpara1[i,10]+(data1[,15+1:16*10]==3)*simpara1[i,11]+(data1[,15+1:16*10]==4)*simpara1[i,12]+(data1[,15+1:16*10]==5)*simpara1[i,13] 
      + (data1[,rep(2,16)]>=5)*simpara1[i,21])

# children 
a2 <- (data1[,11+1:16*10]<18&data1[,11+1:16*10]>=0)*a1
a2 <- as.vector(a2)  
a2 <- a2[a2!=0] 

AR1[i,1] <- mean(exp(a2)*simpara1[i,4])

# adults
a2 <- (data1[,11+1:16*10]>=18&data1[,11+1:16*10]>=0)*a1
a2 <- as.vector(a2)  
a2 <- a2[a2!=0] 

AR1[i,2] <- mean(exp(a2)*simpara1[i,4])

# household size 
a2 <- (data1[,rep(2,16)]<5)*a1
a2 <- as.vector(a2)  
a2 <- a2[a2!=0] 

AR1[i,3] <- mean(exp(a2)*simpara1[i,4])

a2 <- (data1[,rep(2,16)]>=5)*a1
a2 <- as.vector(a2)  
a2 <- a2[a2!=0] 

AR1[i,4] <- mean(exp(a2)*simpara1[i,4])

# for flu B

data1 <- data21  
for (j in 1:nrow(impute2)){
  data1[impute2[j,1],impute2[j,2]*10+15]  <- sample(1:5,1,replace=F,data32[impute2[j,1],impute2[j,2]*5+1:5]) 
}

a1 <- ((data1[,11+1:16*10]<18&data1[,11+1:16*10]>=0)*simpara2[i,8]+(data1[,13+1:16*10]==1)*simpara2[i,9]
       +(data1[,15+1:16*10]==2)*simpara2[i,10]+(data1[,15+1:16*10]==3)*simpara2[i,11]+(data1[,15+1:16*10]==4)*simpara2[i,12]+(data1[,15+1:16*10]==5)*simpara2[i,13] 
       + (data1[,rep(2,16)]>=5)*simpara2[i,21])

# children 
a2 <- (data1[,11+1:16*10]<18&data1[,11+1:16*10]>=0)*a1
a2 <- as.vector(a2)  
a2 <- a2[a2!=0] 

AR2[i,1] <- mean(exp(a2)*simpara2[i,4])

# adults
a2 <- (data1[,11+1:16*10]>=18&data1[,11+1:16*10]>=0)*a1
a2 <- as.vector(a2)  
a2 <- a2[a2!=0] 

AR2[i,2] <- mean(exp(a2)*simpara2[i,4])

# household size 
a2 <- (data1[,rep(2,16)]<5)*a1
a2 <- as.vector(a2)  
a2 <- a2[a2!=0] 

AR2[i,3] <- mean(exp(a2)*simpara2[i,4])

a2 <- (data1[,rep(2,16)]>=5)*a1
a2 <- as.vector(a2)  
a2 <- a2[a2!=0] 

AR2[i,4] <- mean(exp(a2)*simpara2[i,4])

}

write.csv(AR1,"/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/AR1.csv",row.names = F)
write.csv(AR2,"/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/AR2.csv",row.names = F)


aa <- matrix(NA,10000,4)
aa[,1] <- 1-exp(-simpara1[,4]*exp(simpara1[,8]))
aa[,2] <- 1-exp(-simpara1[,4])
aa[,3] <- 1-exp(-simpara2[,4]*exp(simpara2[,8]))
aa[,4] <- 1-exp(-simpara2[,4])