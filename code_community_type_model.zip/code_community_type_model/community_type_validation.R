### program for community type analysis
rm(list = ls())

library(Rcpp)
library(RcppParallel)

########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
  y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
  y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }
  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
  for (i in 1:ncol(mcmc)){
  plot(mcmc[,i],type="l")
  }
  }
  return(y)
}

########

setwd("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp")
sourceCpp("community_type.cpp")

data1 <- as.matrix(read.csv("2018_04_18_data.csv"))
data1[data1[,1]==135,4] <- 817
data1[data1[,1]==127,4] <- 810

data2 <- as.matrix(read.csv("2018_04_18_prob.csv"))

#
simpara1 <- read.csv("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/mcmc_result1.csv")
simpara2 <- read.csv("/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/mcmc_result2.csv")

simpara1 <- simpara1[10000+1:10000*2,-1]
simpara2 <- simpara2[10000+1:10000*2,-1]

AR1 <- AR2 <- matrix(NA,10000,13)

for (i in 1:10000){
aa <- sim_data(as.matrix(data1[data1[,3]==2,]),as.matrix(data2[data1[,3]==2,]),as.vector(as.matrix(simpara1[i,])),5,10)[[1]]
# age
AR1[i,1] <- sum((aa[,16+0:15*10]==1)*(aa[,21+0:15*10]<18))/sum((aa[,16+0:15*10]>=0)*(aa[,21+0:15*10]<18))
AR1[i,2] <- sum((aa[,16+0:15*10]==1)*(aa[,21+0:15*10]>=18))/sum((aa[,16+0:15*10]>=0)*(aa[,21+0:15*10]>=18))

# vaccination
AR1[i,3] <- sum((aa[,16+0:15*10]==1)*(aa[,23+0:15*10]==1))/sum((aa[,16+0:15*10]>=0)*(aa[,23+0:15*10]==1))
AR1[i,4] <- sum((aa[,16+0:15*10]==1)*(aa[,23+0:15*10]==0))/sum((aa[,16+0:15*10]>=0)*(aa[,23+0:15*10]==0))

# community type
AR1[i,5] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==1))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==1))
AR1[i,6] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==2))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==2))
AR1[i,7] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==3))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==3))
AR1[i,8] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==4))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==4))
AR1[i,9] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==5))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==5))

# oseltamivir treatment
AR1[i,10] <- sum((aa[,16+0:15*10]==1)*(aa[,14]-aa[,7]<=2))/sum((aa[,16+0:15*10]>=0)*(aa[,14]-aa[,7]<=2))
AR1[i,11] <- sum((aa[,16+0:15*10]==1)*(aa[,14]-aa[,7]>2))/sum((aa[,16+0:15*10]>=0)*(aa[,14]-aa[,7]>2))

# house size
AR1[i,12] <- sum((aa[,16+0:15*10]==1)*(aa[,2]<=4))/sum((aa[,16+0:15*10]>=0)*(aa[,2]<=4))
AR1[i,13] <- sum((aa[,16+0:15*10]==1)*(aa[,2]>=5))/sum((aa[,16+0:15*10]>=0)*(aa[,5]>=5))


aa <- sim_data(as.matrix(data1[data1[,3]==3,]),as.matrix(data2[data1[,3]==3,]),as.vector(as.matrix(simpara2[i,])),5,10)[[1]]
AR2[i,1] <- sum((aa[,16+0:15*10]==1)*(aa[,21+0:15*10]<18))/sum((aa[,16+0:15*10]>=0)*(aa[,21+0:15*10]<18))
AR2[i,2] <- sum((aa[,16+0:15*10]==1)*(aa[,21+0:15*10]>=18))/sum((aa[,16+0:15*10]>=0)*(aa[,21+0:15*10]>=18))

AR2[i,3] <- sum((aa[,16+0:15*10]==1)*(aa[,23+0:15*10]==1))/sum((aa[,16+0:15*10]>=0)*(aa[,23+0:15*10]==1))
AR2[i,4] <- sum((aa[,16+0:15*10]==1)*(aa[,23+0:15*10]==0))/sum((aa[,16+0:15*10]>=0)*(aa[,23+0:15*10]==0))

AR2[i,5] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==1))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==1))
AR2[i,6] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==2))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==2))
AR2[i,7] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==3))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==3))
AR2[i,8] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==4))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==4))
AR2[i,9] <- sum((aa[,16+0:15*10]==1)*(aa[,25+0:15*10]==5))/sum((aa[,16+0:15*10]>=0)*(aa[,25+0:15*10]==5))

# oseltamivir treatment
AR2[i,10] <- sum((aa[,16+0:15*10]==1)*(aa[,14]-aa[,7]<=2))/sum((aa[,16+0:15*10]>=0)*(aa[,14]-aa[,7]<=2))
AR2[i,11] <- sum((aa[,16+0:15*10]==1)*(aa[,14]-aa[,7]>2))/sum((aa[,16+0:15*10]>=0)*(aa[,14]-aa[,7]>2))

# house size
AR2[i,12] <- sum((aa[,16+0:15*10]==1)*(aa[,2]<=4))/sum((aa[,16+0:15*10]>=0)*(aa[,2]<=4))
AR2[i,13] <- sum((aa[,16+0:15*10]==1)*(aa[,2]>=5))/sum((aa[,16+0:15*10]>=0)*(aa[,5]>=5))


}

write.csv(AR1,"/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/AR1.csv",row.names = F)
write.csv(AR2,"/Volumes/GoogleDrive/My Drive/Nicaragua_flu/community_type/program_rcpp/AR2.csv",row.names = F)
