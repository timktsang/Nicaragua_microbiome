### program for community type analysis
rm(list = ls())

library(Rcpp)
library(RcppParallel)

########
## function to compute the mcmc output
para_summary <- function(mcmc,a,b,print){
  y <- matrix(NA,ncol(mcmc),4)
  for (i in 1:ncol(mcmc)){
  y[i,1:3] <- quantile(mcmc[,i],c(0.5,0.025,0.975))
  y[i,4] <- sum(diff(mcmc[,i])!=0)/nrow(mcmc)
  }

  layout(matrix(1:(a*b),nrow=a,byrow=T))
  par(mar=c(2,4,1,1))
  if (print==1){
  for (i in 1:ncol(mcmc)){
  plot(mcmc[,i],type="l")
  }
  }
  return(y)
}

########

#setwd("/Users/timtsang/Dropbox2/Dropbox/Nicaragua_flu/community_type/program_rcpp/main/v1_oligotype")

data1 <- as.matrix(read.csv("2018_06_09_data.csv"))
data1[data1[,1]==135,4] <- 817
data1[data1[,1]==127,4] <- 810

data2 <- as.matrix(read.csv("2018_06_09_prob.csv"))
data3 <- as.matrix(read.csv("2018_06_09_oligotype.csv"))

# para
# 1: SI para1
# 2: SI para2
# 3: community para
# 4: household para
# 5: H1 vs H3
# 6: B vs H3
# 7: Age <=18, flu A
# 8: Age <=18, flu B
# 9: vaccination
# 10: community type 2
# 11: community type 3
# 12: community type 4
# 13: community type 5
# 14: age inf
# 15: antiviral treatment inf
# 16: community type 2 inf
# 17: community type 3 inf 
# 18: community type 4 inf
# 19: community type 5 inf
# 20: household size 6-7
# 21: household size >7

int_para <-  c(4.98,3.49,0.01,0.2,rep(0,32))
sourceCpp("community_type.cpp")
para <- int_para
sigma <- c(1,1,0.1,0.1,rep(0.5,32))
move <- rep(0,36)
move[c(1:4,8:9,21,21+c(3,15))] <- 1
#para <- c(c(4.98,3.49),runif(2,0.001,5),runif(17,-1,1))
#para[c(5:21)] <- 0

#loglik(data1,int_para,5,10) -> aaa


aaaaa1 <- Sys.time()
tt <- mcmc(data1[data1[,3]==2,],data2[data1[,3]==2,],data3[data1[,3]==2,],30000,int_para,move,sigma)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)

#write.csv(tt[[1]],"mcmc_result.csv")

inc <- 10000+1:10000*2
z1 <- para_summary((tt[[1]][inc,]),4,4,1)
temp1 <- tt[[3]][inc,]
temp1 <- cbind(temp1,sqrt(temp1[,2]-temp1[,1]^2))
z2 <- para_summary(temp1,4,4,0)

z1
z2
#plot(tt[[2]][inc])
#mean(tt[[2]][inc])
write.csv(tt[[1]],"mcmc_result1.csv")
write.csv(rbind(z1,z2),"mcmc_summary1.csv")


#########
aaaaa1 <- Sys.time()
tt <- mcmc(data1[data1[,3]==3,],data2[data1[,3]==3,],data3[data1[,3]==3,],30000,int_para,move,sigma)
aaaaa2 <- Sys.time()
print(aaaaa2-aaaaa1)

#write.csv(tt[[1]],"mcmc_result.csv")

inc <- 10000+1:10000*2
z1 <- para_summary((tt[[1]][inc,]),4,4,1)
temp1 <- tt[[3]][inc,]
temp1 <- cbind(temp1,sqrt(temp1[,2]-temp1[,1]^2))
z2 <- para_summary(temp1,4,4,0)

z1
z2
#plot(tt[[2]][inc])
#mean(tt[[2]][inc])
write.csv(tt[[1]],"mcmc_result2.csv")
write.csv(rbind(z1,z2),"mcmc_summary2.csv")




